#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int val) : data(val), prev(nullptr), next(nullptr) {}
};

class DoublyLinkedList {
private:
    Node* head;
    Node* tail;
    int size;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr), size(0) {}

 
    void addAtStart(int val) {
        Node* newNode = new Node(val);
        if (!head) {
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        size++;
    }

   
    void addAtIndex(int index, int val) {
        if (index < 0 || index > size) {
            cout << "Index out of bounds\n";
            return;
        }

        if (index == 0) {
            addAtStart(val);
            return;
        }

        if (index == size) {
            addAtEnd(val);
            return;
        }

        Node* newNode = new Node(val);
        Node* curr = head;

        for (int i = 0; i < index; ++i) {
            curr = curr->next;
        }

        newNode->prev = curr->prev;
        newNode->next = curr;
        curr->prev->next = newNode;
        curr->prev = newNode;

        size++;
    }


    void addAtEnd(int val) {
        Node* newNode = new Node(val);
        if (!tail) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        size++;
    }

 
    void removeHead() {
        if (!head) return;

        Node* temp = head;
        if (head == tail) {
            head = tail = nullptr;
        } else {
            head = head->next;
            head->prev = nullptr;
        }

        delete temp;
        size--;
    }

   
    void removeAtIndex(int index) {
        if (index < 0 || index >= size) {
            cout << "Index out of bounds\n";
            return;
        }

        if (index == 0) {
            removeHead();
            return;
        }

        if (index == size - 1) {
            removeLast();
            return;
        }

        Node* curr = head;
        for (int i = 0; i < index; ++i) {
            curr = curr->next;
        }

        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;

        delete curr;
        size--;
    }

    void removeLast() {
        if (!tail) return;

        Node* temp = tail;
        if (head == tail) {
            head = tail = nullptr;
        } else {
            tail = tail->prev;
            tail->next = nullptr;
        }

        delete temp;
        size--;
    }

   
    Node* find(int val) {
        Node* curr = head;
        while (curr) {
            if (curr->data == val) return curr;
            curr = curr->next;
        }
        return nullptr;
    }

 
    int get(int index) {
        if (index < 0 || index >= size) {
            cout << "Index out of bounds\n";
            return -1;
        }

        Node* curr = head;
        for (int i = 0; i < index; ++i) {
            curr = curr->next;
        }

        return curr->data;
    }

 
    Node* start() {
        return head;
    }

  
    void printList() {
        Node* curr = head;
        cout << "List: ";
        while (curr) {
            cout << curr->data << " ";
            curr = curr->next;
        }
        cout << endl;
    }
};


int main() {
    DoublyLinkedList dll;

    dll.addAtStart(10);
    dll.addAtEnd(20);
    dll.addAtEnd(30);
    dll.addAtIndex(1, 15);
    dll.printList();

    dll.removeAtIndex(2);
    dll.printList(); 

    Node* found = dll.find(15);
    if (found) {
        cout << "Found: " << found->data << endl;
    }

    cout << "Element at index 1: " << dll.get(1) << endl;

    dll.removeHead();
    dll.removeLast();
    dll.printList(); 

    return 0;
}

